<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSanimacion/animacion.css">
    <title>TODO DEPORTES</title>
</head>
<body>
    <script>
        setTimeout(function() {
            window.location.href = "http://localhost/olimpiadas/inicio/index.php";
            }, 10);
    </script> 
</body>
</html>