<?php

include_once('carrito/conexion.php');

$carrito = "SELECT * FROM productos";
$resultado = mysqli_query($conn, $carrito);

while($row = $resultado->fetch_assoc()):?>
<div class="productos">
    <div class="cajaproductos">
        <ul>
            <!-- <?= $row['id'] ?> -->
            <?= $row['tipo'] ?>
            <?= $row['marca'] ?>
            <?= $row['modelo'] ?>
            $<?= $row['precio'] ?> 
            <form action="http://localhost/olimpiadas/usuarios/index.php?view=cargacarrito" method="post">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <input type="hidden" name="tipo" value="<?= $row['tipo'] ?>">
                <input type="hidden" name="marca" value="<?= $row['marca'] ?>">
                <input type="hidden" name="modelo" value="<?= $row['modelo'] ?>">
                <input type="hidden" name="precio" value="<?= $row['precio'] ?>">
                <input type="number" name="cantidad" min="1">
                <button class="agregaralcarrito" type="submit">Agregar al carrito</button>
            </form>
        </ul>
    </div>
</div>
        
<?php 
    endwhile;
?>


<form action="vistas/factura/factura.php" method="post">
    <input type="hidden" name="id" value="<?=$_SESSION['usuario']?>">
    <button type="submit">Enviar Factura</button>
</form>


<!-- <a href="vistas/factura/factura.php">Factura</a> -->