<?php
    
    include_once('conexion.php');
    session_start();
    // guarda en una variable el nombre de usuario que llega por POST
    $usuario = $_SESSION['usuario'];
    
    // guarda en una variable la contraseña que llega por POST
    $comentario = $_POST['comentario'];
    
    $ingresarcomentario = "INSERT INTO comentarios (idusuario, comentarios) VALUES ('".$usuario."', '".$comentario."')";

    $resultado = mysqli_query($conexión,$ingresarcomentario);

    if ($ingresarcomentario)
    {
        header("Location:http://localhost/olimpiadas/usuarios/index.php");
    } else {
        echo "Error";
    }

?>