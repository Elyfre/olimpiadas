<?php
session_start(); //se resume la sesion existente
session_unset(); //borramos variables de la sesion
session_destroy(); //cerramos la sesion

header("Location: http://localhost/olimpiadas/inicio/index.php"); //redirigimos a pag principal

?>