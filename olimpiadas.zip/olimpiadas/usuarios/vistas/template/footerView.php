<footer>
    <p>Página oficial de TODO DEPORTE</p>

    <div class="comentdiv">
        <div class="comentarioscont">
            <form class="comentform" action="vistas/comentarios/comentarios.php" method="post">
                <input type="hidden" name="usuario" value="'.$_SESSION['usuario']'">
                <input type="text" name="comentario" placeholder="Ingrese su comentario...">
                <button id="btncoment" type="submit">Enviar comentario</button>
            </form>
            <a class="btnvercoment" href="http://localhost/olimpiadas/usuarios/index.php?view=comentarios">Ver comentarios</a>
        </div>
    </div>

    <!-- SECCION DE INFO Y PREGUNTAS -->
    <div class="footerinf">
        <div class="consultasfooter">
            <div class="footercompr">

                <!-- COMO COMPRAR -->
                <div class="item2">
                    <div id="myNavv" class="overlayy">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNavv()">&times;</a>
                        <div class="overlaycontentt">
                            <h3>¿Como comprar?</h3>
                            <p>Para comprar debe agregar al carrito los productos que desee.</p>
                        </div>
                    </div>
                    <span style="font-size:16px;cursor:pointer; margin: 5%" onclick="openNavv()">¿Como comprar?</span>
                </div>

                <!-- QUIENES SOMOS -->
                <div class="item3">
                    <div id="myNavvv" class="overlayyy">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNavvv()">&times;</a>
                        <div class="overlaycontenttt">
                            <h3>¿Quienes somos?</h3>
                            <p>TODO DEPORTES es una empresa de venta de indumentaria para actividades al aire libre.</p>
                        </div>
                    </div>
                    <span style="font-size:16px;cursor:pointer; margin: 5%" onclick="openNavvv()">¿Quienes somos?</span>
                </div>

                <!-- MEDIOS DE PAGO -->
                <div class="item4">
                    <div id="myNavvvv" class="overlayyyy">
                        <a href="javascript:void(0)" class="closebtn" onclick="closeNavvvv()">&times;</a>
                        <div class="overlaycontentttt">
                            <h3>Medios de pago</h3>
                            <p>Para comprar debe agregar al carrito los productos que desee.</p>
                        </div>
                    </div>
                    <span style="font-size:16px;cursor:pointer; margin: 5%" onclick="openNavvvv()">Medios de pago</span>
                </div>

            </div>
        </div>

        <!-- SECCION DE CONTACTOS -->
        <div class="contactosfooter">
            <div class="logos">
                <a href="https://www.whatsapp.com" target="_blank">
                    <img class="whatsapp" src="assets/img/LOGOWHATSAPP.png" alt="WhatsApp">
                </a>
                <a href="mailto:mgomezbarbuto@gmail.com">
                    <img class="gmail" src="assets/img/LOGOGMAIL.png" alt="Gmail">
                </a>
            </div>
            <div class="redes">
                <a href="https://www.whatsapp.com" target="_blank">+54 2262 516032</a>
                <a href="mailto:mgomezbarbuto@gmail.com">mgomezbarbuto@gmail.com</a>
            </div>
        </div>
    </div>
</footer>

<script type="text/javascript" src="assets/js/scrip.js"></script>
</body>
</html>