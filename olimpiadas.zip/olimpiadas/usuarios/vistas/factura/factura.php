<?php
require('fpdf/fpdf.php');

class PDF extends FPDF
{
// Cabecera de página
function Header()
{
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Movernos a la derecha
    $this->Cell(80);
    // Título
    $this->Cell(30,10,'Title',1,0,'C');
    // Salto de línea
    $this->Ln(20);
}

// Pie de página
function Footer()
{
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

require_once('conexion.php');
session_start();


$historial = "SELECT * FROM historialcarrito WHERE idusuario = '".$_SESSION['usuario']."' ";
$resultado = mysqli_query($conn, $historial);

// Creación del objeto de la clase heredada
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

if (mysqli_num_rows($resultado)>0) {
    while ($fila = mysqli_fetch_assoc($resultado)) {
        
        $carrito_usuario = unserialize($fila['carrito']);
        // var_dump($carrito_usuario);
        $cantidad_items_carrito = count($carrito_usuario);
        for ($i=0; $i < $cantidad_items_carrito; $i++) {
            $pdf->Cell(80, 10, $carrito_usuario[$i]['tipo'],1,1,'C',0);
            $carrito_usuario[$i]['marca'];
            $carrito_usuario[$i]['modelo'];
            $carrito_usuario[$i]['cantidad'];
            $carrito_usuario[$i]['precio'];
        }
    }
}

$pdf->Output();

?>