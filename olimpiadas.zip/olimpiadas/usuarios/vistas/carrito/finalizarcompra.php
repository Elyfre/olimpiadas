<?php
    include_once('conexion.php');
    // session_start();

    $carrito_pendiente = serialize($_SESSION['carrito']);

    $historial = "INSERT INTO historialcarrito (carrito, estado, idusuario) VALUES ('".$carrito_pendiente."', 'pendiente', '".$_SESSION['usuario']."')";
    $resultado = mysqli_query($conn, $historial);


    if ($resultado) {
        echo "Le avisaremos cuando su compra este aceptada";
        $_SESSION['carrito'] = [];
    }
    else {
        echo "Error, no pudimos cargar su carrito";
    }
?>