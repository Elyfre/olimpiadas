<?php

    $indice = $_POST['index'];
    // session_start();

?>

<div class="productomodificarcaja">
    <div class="productomodificar">
        <?php
            $datos_producto = $_SESSION['carrito'][$indice];

            echo " " .$_SESSION['carrito'][$indice]['tipo']."";
            echo " " .$_SESSION['carrito'][$indice]['marca']."";
            echo " " .$_SESSION['carrito'][$indice]['modelo']."<br>";
            echo "<br>";
            echo "Precio: $" .$_SESSION['carrito'][$indice]['precio']."<br>";
            echo "Sub Total: " .$_SESSION['carrito'][$indice]['subtotal']."";

            echo '<form action="vistas/carrito/modificar_item_en_carrito.php" method="post">
                <input hidden type="text" name="indice" value="'.$indice.'">
                <input type="hidden" name="tipo" value="'.$_SESSION['carrito'][$indice]['tipo'].'">
                <input type="hidden" name="marca" value="'.$_SESSION['carrito'][$indice]['marca'].'">
                <input type="hidden" name="modelo" value="'.$_SESSION['carrito'][$indice]['modelo'].'">
                <input type="hidden" name="precio" value="'.$_SESSION['carrito'][$indice]['precio'].'">
                <input type="hidden" name="subtotal" value="'.$_SESSION['carrito'][$indice]['subtotal'].'">
                <input type="number" name="cantidad" placeholder="cantidad" value="'.$_SESSION['carrito'][$indice]['cantidad'].'">
                <button type="submit">Modificar Producto</button>
            </form>';
        ?>
    </div>
    
</div>