<div class="carritoproduc">

    <?php
        include_once('conexion.php');
        // session_start();

        if (!isset($_SESSION['carrito'])) {
            $_SESSION['carrito'] = [];
        }

        $limite = count($_SESSION['carrito']); //tomamos la cantidad de productos (limite)
        $total = 0;
    ?>
    <div class="producto">
        <?php
            for ($i=0; $i < $limite ; $i++) { //recorremos cada producto
                foreach ($_SESSION['carrito'][$i] as $x => $y) { //recorremos cada dato dentro del producto
                    echo "$x: $y <br>";
                }
                echo "<br>";?>
                <div class="botonesproducto">
                    <?php
                        echo '<form action="vistas/carrito/borrar_item_carrito.php" method="post">
                                <input hidden type="number" name="index" value="'.$i.'">
                                <input id="btnborrarc" type="submit" value="borrar">
                        </form>';
                        echo '<form action="http://localhost/olimpiadas/usuarios/index.php?view=modificarcarro" method="post">
                                <input hidden type="number" name="index" value="'.$i.'">
                                <button id="btnmodificarc" type="submit">Modificar</button>
                        </form>';
                        echo "<br>";
                    ?>
                </div>
                <?php
            }
        ?>
    </div>
        
    <?php 
        echo '<form action="http://localhost/olimpiadas/usuarios/index.php?view=finalizar" method="post">
            <button id="btnfinalizar" type="submit">Finalizar</button>
        </form>';
    ?>
    
    <a id="linkvaciar" href="vistas/carrito/vaciarcarrito.php">Vaciar carrito</a>
</div>