<?php

$index = $_POST['index'];
session_start(); //resumimos la sesion para traer los datos del carrito

if ($index == 0) {
    array_shift($_SESSION['carrito']);
} else {
    //borramos el index del carrito (no el carrito si no el producto)
    array_splice($_SESSION['carrito'], $index, $index);
}

header("Location: http://localhost/olimpiadas/usuarios/index.php?view=carrito");
?>