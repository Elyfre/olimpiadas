<?php
// session_start(); //resumimos la sesion
$_SESSION['carrito'] = array(); //restablecemos el carrito

header("Location: http://localhost/olimpiadas/usuarios/index.php?view=carrito"); //redirigimos a pag principal
?>