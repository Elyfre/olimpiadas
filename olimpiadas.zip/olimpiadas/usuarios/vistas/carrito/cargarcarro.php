<?php
include_once('conexion.php');
// session_start();
?>

    <?= $id = $_POST['id']; ?>
    <?= $tipo = $_POST['tipo']; ?>
    <?= $marca = $_POST['marca']; ?>
    <?= $modelo = $_POST['modelo']; ?>
    <?= $cantidad = $_POST['cantidad']; ?>
    <?= $precio = $_POST['precio']; ?>

<?=
//creamos el arreglo del producto con sus datos
 $datos_producto = array("tipo"=>$tipo, "marca"=>$marca, "modelo"=>$modelo, "cantidad"=>$cantidad, "precio"=>$precio, "subtotal" => ($cantidad * $precio)); //armamos un arreglo con los datos del producto

$mi_carrito = $_SESSION['carrito']; //tomamos el valor actual del carrito
array_push($mi_carrito,$datos_producto); //pusheamos el nuevo producto al carrito

$_SESSION['carrito'] = $mi_carrito; //reemplazamos el nuevo valor del carrito;

header("Location: http://localhost/olimpiadas/usuarios/index.php"); //redirigimos al index
?>