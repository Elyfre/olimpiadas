<?php
session_start();

$indice = $_POST['indice'];
$tipo = $_POST['tipo'];
$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$cantidad = $_POST['cantidad'];
$precio = $_POST['precio'];
$subtotal = $_POST['subtotal'];


$producto = $_SESSION['carrito'][$indice];

//armo el producto modificado
$datos_nuevos = array("tipo"=>$tipo, "marca"=>$marca, "modelo"=>$modelo, "cantidad"=>$cantidad, "precio"=>$precio, "subtotal"=>($subtotal * $cantidad));
print_r($datos_nuevos);
//reemplazar el producto de mismo indice en la sesion
$_SESSION['carrito'][$indice] = $datos_nuevos;

//redireccion
header("Location: http://localhost/olimpiadas/usuarios/index.php?view=carrito");

?>