<?php

require_once("vistas/template/headerView.php"); // abre el header y lo deja anclado al comienzo de la pagina

    $view = $_GET['view'] ?? ''; // recibe la palabra del 'view' enviada por metodo GET
    switch ($view) {
        case 'finalizar':
            require_once"vistas/carrito/finalizarcompra.php";
            break;
        case 'cargacarrito':
            require_once"vistas/carrito/cargarcarro.php";
            break;
        case 'modificarcarro':
            require_once"vistas/carrito/modificar_item_carrito.php";
            break;
        case 'carrito':
            require_once"vistas/carrito/carrito.php";
            break; // recibe la palabra 'carrito' y te direcciona a la pagina/vista correspondiente
        case 'comentarios':
            require_once"vistas/comentarios/comentariosView.php";
            break;
        default:
            require_once"vistas/welcomeView.php"; // la página principal, se abre si no entra ninguna palabra por la variable view
            break;
    }

require_once("vistas/template/footerView.php"); // abre el footer y lo deja anclado al final

?>