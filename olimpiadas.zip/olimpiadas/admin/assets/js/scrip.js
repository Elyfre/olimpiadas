function openNav() {  // abre la informacion del footer // 
    document.getElementById("myNav").style.height = "100%";
}

function openNavv() {  // abre la informacion del footer // 
    document.getElementById("myNavv").style.height = "100%";
}

function openNavvv() {  // abre la informacion del footer // 
    document.getElementById("myNavvv").style.height = "100%";
}

function openNavvvv() {  // abre la informacion del footer // 
  document.getElementById("myNavvvv").style.height = "100%";
}


function closeNav() {   // cierra la informacion del footer // 
document.getElementById("myNav").style.height = "0%";
}

function closeNavv() {   // cierra la informacion del footer // 
    document.getElementById("myNavv").style.height = "0%";
}

function closeNavvv() {   // cierra la informacion del footer // 
    document.getElementById("myNavvv").style.height = "0%";
}

function closeNavvvv() {   // cierra la informacion del footer // 
  document.getElementById("myNavvvv").style.height = "0%";
}




document.addEventListener('DOMContentLoaded', function() {
    var buttons = document.querySelectorAll('.menu-btn');

    buttons.forEach(function(button) {
      button.addEventListener('click', function() {
        var menuId = button.getAttribute('data-menu');
        var dropdown = document.getElementById(menuId);
        
        // Si el menú está visible, ocultarlo y mostrar todos los botones
        if (dropdown.classList.contains('show')) {
          dropdown.classList.remove('show');
          buttons.forEach(function(btn) {
            btn.style.display = 'inline-block';
          });
        } else { // Si el menú está oculto, mostrar solo el botón clickeado
          buttons.forEach(function(btn) {
            if (btn === button) {
              btn.style.position = 'relative';
              btn.style.top = 0;
            } else {
              btn.style.display = 'none';
              btn.style.opacity = 30;
            }
          });
          
          // Mostrar el menú correspondiente
          dropdown.classList.add('show');
          
          // Ocultar todos los menús excepto el correspondiente
          document.querySelectorAll('.dropdown-menu').forEach(function(menu) {
            if (menu !== dropdown) {
              menu.classList.remove('show');
            }
          });
        }
      });
    });
  });