<div id="productos" style="display: block;" class="productos">
        <?php

        include_once('vistas/acciones/conexion.php');
        // session_start();


        $carrito = "SELECT * FROM productos";
        $resultado = mysqli_query($conn, $carrito);

        while($row = $resultado->fetch_assoc()):?>
        <div class="cajaproducto">
            <ul>
                <!-- <?= $row['id'] ?> -->
                <?= $row['tipo'] ?>
                <?= $row['marca'] ?>
                <?= $row['modelo'] ?>
                <br>
                $<?= $row['precio'] ?>
                
                <div class="btnsproduct">
                    <form action="vistas/acciones/borrar_producto.php" method="post">
                        <input type="hidden" name="borrar" value="<?= $row['id'] ?>">
                        <button id="btnborrarproduct" class="btnmodproduc" type="submit">Borrar elemento</button>
                    </form>
                    <form action="http://localhost/olimpiadas/admin/index.php?view=modificar" method="post">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <input type="hidden" name="tipo" value="<?= $row['tipo'] ?>">
                        <input type="hidden" name="marca" value="<?= $row['marca'] ?>">
                        <input type="hidden" name="modelo" value="<?= $row['modelo'] ?>">
                        <input type="hidden" name="precio" value="<?= $row['precio'] ?>">
                        <button class="btnmodproduc" type="submit">Modificar elemento</button>
                    </form>
                </div>
                
            </ul> 
        </div>
        <?php 
            endwhile;
        ?>
    </div>
    </main>
