<?php
include_once('conexion.php');
session_start();

$id = $_POST['id'];

$borrar = "DELETE FROM comentarios WHERE id = ".$id."";

$resultado = mysqli_query($conexión, $borrar);

//si funciona
if ($resultado) {
    //redirecciona la vista
    header("Location: http://localhost/olimpiadas/admin/index.php?view=comentarios");
} else {
    //mensaje de error
    echo "No se elimino";
}




?>