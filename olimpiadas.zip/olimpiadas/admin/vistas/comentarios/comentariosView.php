<?php

include_once('conexion.php');
// session_start();

$comentarios = "SELECT * FROM comentarios";
$resultado = mysqli_query($conexión, $comentarios);

while($row = $resultado->fetch_assoc()):?>
    <div class="contcomentariosview">
        <div class="comentarioview">
            <div class="usuariocoment">
                <?= $row['idusuario']  ?>:<br>
            </div>
            <?= $row['comentarios'] ?><br>
            <form action="vistas/comentarios/borrarcomentarios.php" method="post">
                <input type="hidden" name="id" value="<?=$row['id']?>">
                <button class="btnborrarcoment" type="submit">Borrar comentario</button>
            </form>
        </div>
    </div>
            
<?php 
    endwhile;
?>