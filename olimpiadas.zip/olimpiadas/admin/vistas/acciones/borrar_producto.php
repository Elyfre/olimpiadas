<?php

include_once('conexion.php');
session_start();

$idborrar = $_POST['borrar'];

$borrar = "DELETE FROM productos WHERE id = ".$idborrar."";

$resultado = mysqli_query($conn, $borrar);

//si funciona
if ($resultado) {
    //redirecciona la vista
    header("Location: http://localhost/olimpiadas/admin/index.php");
} else {
    //mensaje de error
    echo "No se elimino";
}

?>