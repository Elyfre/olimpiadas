<?php
include_once('conexion.php');
session_start();

$tipo = $_POST['tipo'];
$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$precio = $_POST['precio'];


$nuevo = "INSERT INTO productos (tipo, marca, modelo, precio) VALUES ('".$tipo."','".$marca."','".$modelo."','".$precio."')";
$resultadoingresar=mysqli_query($conn,$nuevo);


// si funciona
if ($resultadoingresar) {
    //redirecciona la vista
    header("Location: http://localhost/olimpiadas/admin/index.php");
} else {
    //mensaje de error
    echo "No se modificó";
}

?>