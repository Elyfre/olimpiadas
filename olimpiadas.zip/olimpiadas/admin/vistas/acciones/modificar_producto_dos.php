<?php

include('conexion.php');
session_start();

$id = $_POST['id'];
$tipo = $_POST['tipo']; 
$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$precio = $_POST['precio'];

$modificar = "UPDATE productos SET tipo = '".$tipo."', marca = '".$marca."', modelo = '".$modelo."', precio = '".$precio."' WHERE id = '".$id."'";

$resultado = mysqli_query($conn, $modificar);

// si funciona
if ($resultado) {
    //redirecciona la vista
    header("Location: http://localhost/olimpiadas/admin/index.php");
} else {
    //mensaje de error
    echo "No se modificó";
}

?>