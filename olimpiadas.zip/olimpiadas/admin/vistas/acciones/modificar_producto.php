<?php
// include_once('conexion.php');
// session_start();

$id = $_POST['id'];
$tipo = $_POST['tipo']; 
$marca = $_POST['marca'];
$modelo = $_POST['modelo'];
$precio = $_POST['precio'];
?>
<div class="cargarproduct">
<?php
echo '<form class="formcargarproduct" action="vistas/acciones/modificar_producto_dos.php" method="post">
        <input type="hidden" name="id" value="'.$id.'">
        <input type="text" name="tipo" value="'.$tipo.'">
        <input type="text" name="marca" value="'.$marca.'">
        <input type="text" name="modelo" value="'.$modelo.'">
        <input type="number" name="precio" value="'.$precio.'">
        <button type="submit">Modificar Producto</button>
    </form>';
?>
</div>