<?php

$nombreServidor = "localhost"; //servidor local
$usuario = "root"; //usuario del servidor mysql
$contra = "";
$bd = "olimpiadas"; // nombre de la base de datos

// conexion con la base de datos con los parametros
$conn = mysqli_connect($nombreServidor, $usuario, $contra, $bd);

// comprobacion de conexion
if (!$conn) {
    echo "Fallo la conexión, el error es: " . mysqli_connect_error();
} else {
    echo "";
}

?>