<?php
include_once('vistas/acciones/conexion.php');
// session_start();
?>
<div class="cargarproduct">
    <form class="formcargarproduct" action="vistas/acciones/cargar_productos_dos.php" method="post">
        <input type="text" name="tipo" placeholder="Tipo de producto...">
        <input type="text" name="marca" placeholder="Marca...">
        <input type="text" name="modelo" placeholder="Modelo...">
        <input type="number" name="precio" placeholder="Precio $...">
        <button type="submit">Cargar producto</button>
    </form>
</div>

