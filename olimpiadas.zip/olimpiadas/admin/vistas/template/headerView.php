<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TODO DEPORTES</title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
</head>
<body>
<header>
    <div class="cabeceratotal">
        <div class="cabecera">
            <img class="logo" src="assets/img/logotd.png" alt="Logo">
            <div class="linkcs">
                <a class="cerrarsesion" href="vistas/cerrarsesion/cerrarsesion.php"><?php session_start(); echo $_SESSION['usuario']?> <br> (cerrar sesión)</a>
            </div>
        </div>
        <div class="botonera">
            <a id="btnnro1" href="http://localhost/olimpiadas/admin/index.php">Productos</a>
            <a id="btnnro2" href="http://localhost/olimpiadas/admin/index.php?view=ventas">Ventas</a>
            <a id="btnnro3" href="http://localhost/olimpiadas/admin/index.php?view=cargar">Cargar Productos</a>
        </div>
    </div>
</header>