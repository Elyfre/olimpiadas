<footer>
    <p>Página oficial de TODO DEPORTE</p>

    <div class="comentdiv">
        <div class="comentarioscont">
            <a class="btnvercoment" href="http://localhost/olimpiadas/admin/index.php?view=comentarios">Ver comentarios</a>
        </div>
    </div>

</footer>
</body>
</html>