<?php
    include_once('conexion.php');
    // session_start();

    $historial = "SELECT * FROM historialcarrito WHERE estado = 'pendiente'" ; //WHERE estado = "pendiente"
    $resultado = mysqli_query($conn, $historial);
    
    echo "<h2>Pedidos por confirmar:</h2>";
    echo "<br>";
    echo "<br>";


    if (mysqli_num_rows($resultado)>0) {
        while ($fila = mysqli_fetch_assoc($resultado)) {
            
            $carrito_usuario = unserialize($fila['carrito']);
            // var_dump($carrito_usuario);
            $cantidad_items_carrito = count($carrito_usuario);
            ?><div class="cajaproducto">
                <ul>
                    <?php
                    echo "<h4>Pedido de compra de: </h4>".$fila['idusuario'];
                    echo "<br>";
                    echo "ID de compra: ".$fila['id'];
                    echo "<br>";
                    echo "<br>";
                    for ($i=0; $i < $cantidad_items_carrito; $i++) {
                        echo $carrito_usuario[$i]['tipo']." ".
                        $carrito_usuario[$i]['marca']." ".
                        $carrito_usuario[$i]['modelo']. "<br>";
                        echo "Cantidad: ".$carrito_usuario[$i]['cantidad']."<br>";
                        echo "Precio Unitario: ".$carrito_usuario[$i]['precio']."<br>";
                        echo "Total: ".$carrito_usuario[$i]['cantidad'] * $carrito_usuario[$i]['precio']. "<br>";  
                        echo "<br>";
                    }
                    echo '<form action="vistas/ventas/aceptarpedidos.php" method="post">
                            <input type="hidden" name="id" value='.$fila['id'].'>
                            <input type="hidden" name="estado" value="aprobado">
                            <button id="btnborrarproduct" class="btnmodproduc" type="submit">Aprobar</button>
                        </form>';
                    echo '<form action="vistas/ventas/denegarpedidos.php" method="post">
                            <input type="hidden" name="id" value='.$fila['id'].'>
                            <input type="hidden" name="estado" value="denegado">
                            <button class="btnmodproduc" type="submit">Denegar</button>
                        </form>';
                    ?>
                </ul>
            </div>
        <?php
        }
    } else {
        echo "Sin pedidos por confirmar";
    }
    
?>


