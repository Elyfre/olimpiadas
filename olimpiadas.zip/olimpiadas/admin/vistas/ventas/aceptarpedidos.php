<?php
include_once('conexion.php');

$id = $_POST['id'];
$estado = $_POST['estado'];

$modificar = "UPDATE historialcarrito SET estado = '".$estado."' WHERE id = '".$id."'";

$resultado = mysqli_query($conn, $modificar);

// si funciona
if ($resultado) {
    header("Location: http://localhost/olimpiadas/admin/index.php?view=ventas");
} else {
    //mensaje de error
    echo "No se modificó";
}