<?php

require_once("vistas/template/headerView.php"); // abre el header y lo deja anclado al comienzo de la pagina

    $view = $_GET['view'] ?? ''; // recibe la palabra del 'view' enviada por metodo GET
    switch ($view) {
        case 'ventas':
            require_once"vistas/ventas/ventas.php";
            break;
        case 'comentarios':
            require_once"vistas/comentarios/comentariosView.php";
            break; // recibe la palabra 'carrito' y te direcciona a la pagina/vista correspondiente
        case 'cargar':
            require_once"vistas/acciones/cargar_productos.php";
            break;       
        case 'modificar':
            require_once"vistas/acciones/modificar_producto.php";
            break;
        default:
            require_once"vistas/welcomeView.php"; // la página principal, se abre si no entra ninguna palabra por la variable view
            break;
    }

require_once("vistas/template/footerView.php"); // abre el footer y lo deja anclado al final

?>