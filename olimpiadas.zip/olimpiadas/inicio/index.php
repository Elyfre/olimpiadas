<?php

require_once("vistas/template/headerView.php"); // abre el header y lo deja anclado al comienzo de la pagina

    $view = $_GET['view'] ?? ''; // recibe la palabra del 'view' enviada por metodo GET
    switch ($view) {
        case 'sesion':
            require_once"vistas/sesiones/login.php";
            break;  // recibe la palabra 'sesion' y te direcciona a la pagina/vista correspondiente
        case 'registro':
            require_once"vistas/sesiones/register.php";
            break;  // recibe la palabra 'plantillas' y te direcciona a la pagina/vista correspondiente
        default:
            require_once"vistas/welcomeView.php"; // la página principal, se abre si no entra ninguna palabra por la variable view
            break;
    }

require_once("vistas/template/footerView.php"); // abre el footer y lo deja anclado al final

?>