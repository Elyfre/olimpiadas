<?php
    
    include_once('conexion.php');

    // guarda en una variable el nombre de usuario que llega por POST
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM usuarios WHERE email = '$usuario' AND password = '$password' ";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result)>0){
        echo 'Ya existe una persona con estos datos';        
    }
    else {

        $ingresarusuario = "INSERT INTO usuarios (email, password, admin) VALUES ('".$usuario."','".$password."', '0')";
        $resultado = mysqli_query($conn,$ingresarusuario); 

        if ($resultado) {
            session_start();
            $_SESSION['usuario'] = $usuario;
            $_SESSION['carrito'] = array();
            header("Location:http://localhost/olimpiadas/usuarios/index.php");
        } 
        else {
            echo "Error";
        }
    }

?>