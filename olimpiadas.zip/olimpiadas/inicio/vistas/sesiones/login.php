<?php

include_once('conexion.php');

$usuario = $_POST['usuario'];
$password = $_POST['password'];

$sql = "SELECT * FROM usuarios WHERE email = '$usuario' AND password = '$password' ";
$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $admin = $row['admin'];
    if ($admin == 1) {
        session_start();
        $_SESSION['usuario'] = $usuario;
        header("Location: http://localhost/olimpiadas/admin/index.php");
    } else {
    // Inicio de sesión exitoso, crear sesión y redirigir a productos.php
        session_start();
        $_SESSION['usuario'] = $usuario;
        $_SESSION['carrito'] = [];
        header("Location: http://localhost/olimpiadas/usuarios/index.php");
    }
} else {
    echo "Usuario o contraseña incorrectos";
}

?>