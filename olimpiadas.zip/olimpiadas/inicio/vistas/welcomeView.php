<main class="fondo" id="grad1">

    <div class="btnswelcomeview">
    
        <button id="btninicio" class="btninicio" onclick= 'btndesaparecer()' >INICIAR SESIÓN</button>

        <div id="id01" style="display: none;" class="modal">
            <form class="login-form formwelcview" action="http://localhost/olimpiadas/inicio/index.php?view=sesion" method="POST">
                <!-- ingresas el usuario -->
                <label id="formitems" class="formitemsuno" for="usuario"><b>Usuario</b></label>
                <input id="formitems" type="text" name="usuario" placeholder="Nombre de Usuario..." required>
                
                <!-- ingresas la contraseña -->
                <label id="formitems" for="contraseña"><b>Contraseña</b></label>
                <input id="formitems" type="password" name="password" placeholder="Contraseña..." required>
                
                <!-- boton para enviar formulario -->
                <button id="formitems" class="btnform" type="submit">Iniciar Sesión</button>
                <button id="formitems" class="btnform" type="button" onclick='aparecerbtn()' class="cancelbtn">Cancel</button>
            </form>
        </div>

        <button id="btnregistro" class="btnregistro" onclick= 'btndesaparecerr()' >REGISTRARSE</button>

        <div id="id011" style="display: none;" class="modal">
            <form class="register-form formwelcview" action="http://localhost/olimpiadas/inicio/index.php?view=registro" method="POST">
                <!-- ingresas el usuario -->
                <label id="formitems" class="formitemsuno" for="usuario"><b>Usuario</b></label>
                <input id="formitems" type="text" name="usuario" placeholder="Nombre de Usuario..." required>
                
                <!-- ingresas la contraseña -->
                <label id="formitems" for="contraseña"><b>Contraseña</b></label>
                <input id="formitems" type="password" name="password" placeholder="Contraseña..." required>
                
                <!-- boton para enviar formulario -->
                <button id="formitems" class="btnform" type="submit">Registrarme</button>
                <button id="formitems" class="btnform" type="button" onclick='aparecerrbtn()' class="cancelbtn">Cancel</button>
            </form>
        </div>
    
    </div>

    <div id="productos" style="display: block;" class="productos">
        <?php

        include_once('vistas/sesiones/conexion.php');
        session_start();


        $carrito = "SELECT * FROM productos";
        $resultado = mysqli_query($conn, $carrito);

        while($row = $resultado->fetch_assoc()):?>
        <div class="cajaproducto">
            <ul>
                <!-- <?= $row['id'] ?> -->
                <?= $row['tipo'] ?>
                <?= $row['marca'] ?>
                <?= $row['modelo'] ?>
                <br>
                $<?= $row['precio'] ?>
            </ul> 
        </div>
        
        <?php 
            endwhile;
        ?>
    </div>
    
    </main>



<script>

function btndesaparecer() {
    document.getElementById('id01').style.display='block';
    document.getElementById('btninicio').style.display='none';
    document.getElementById('btnregistro').style.display = 'none';
    document.getElementById('productos').style.display = 'none';

}

function aparecerbtn() {
    document.getElementById('id01').style.display='none';
    document.getElementById('btninicio').style.display = 'block';
    document.getElementById('btnregistro').style.display = 'block';
    document.getElementById('productos').style.display = 'block';

}

function btndesaparecerr() {
    document.getElementById('id011').style.display='block';
    document.getElementById('btninicio').style.display='none';
    document.getElementById('btnregistro').style.display = 'none';
    document.getElementById('productos').style.display = 'none';
}

function aparecerrbtn() {
    document.getElementById('id011').style.display='none';
    document.getElementById('btninicio').style.display = 'block';
    document.getElementById('btnregistro').style.display = 'block';
    document.getElementById('productos').style.display = 'block';
}
</script>