<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TODO DEPORTES</title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
</head>
<body>
<header>
    <div class="cabecera">
        <img class="logo" src="assets/img/logotd.png" alt="Logo">
    </div>
</header>